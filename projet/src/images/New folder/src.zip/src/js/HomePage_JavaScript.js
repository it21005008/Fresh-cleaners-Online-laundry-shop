function loadData(name){
	if(name=="btn1"){
		
		document.getElementById("bimage").src="images/HomePage/bgimg/bimg1.jpg";
		
	}
	else if(name=="btn2"){
	
	document.getElementById("bimage").src="images/HomePage/bgimg/bimg2.jpg";
		
	}	
else if(name=="btn3"){

	document.getElementById("bimage").src="images/HomePage/bgimg/bimg3.jpg";
		
	}	

}